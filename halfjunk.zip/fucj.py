import tweepy
# from tweepy.auth import OAuthHandler

consumer_key = "F4qkI1e4TVGd9c4Pmt7QMlqIU"
consumer_secret = "BTh4zrkPHXKFwf8ZZAuDuSk2zOR1BRfWFpDTtxxK8v4xkktRSk"
access_token = "1202438571426230272-poM7DncESffxzoqs6rehQl6e0dtTss"
access_token_secret = "7EE9fseOB5E0LHEsQpZ8q5ppokibbOjrFyKwz6VMvCTpv"
# auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
# auth.set_access_token(access_token, access_token_secret)
# api = tweepy.API(auth)

# user = api.get_user(1088398616)                                                           
# user.screen_name


auth = tweepy.AppAuthHandler(consumer_key, consumer_secret)
# auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)

public_tweets = api.home_timeline()
for tweet in public_tweets:
    print(tweet.text)

