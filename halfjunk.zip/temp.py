#!/usr/bin/env python3

import glob
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import dates

filepaths = []
tmstmp = []
tmpt = []

for f in glob.iglob(r'/home/mgurvich/Downloads/poll-logs/*.json'):
    filepaths.append(f)
filepaths.sort()
for f in filepaths:
    j = json.load(open(f,))
    for i in j["log_data"]:
        tmpt.append(i["cpu_temperature_celsius"])
        tmstmp.append(i["timestamp"])
data = np.array([tmstmp,tmpt])

np.savetxt("MD_data.csv",np.transpose(data),delimiter=',', header='string', comments='', fmt='%s')
# print(dates.date2num(data[0]))

# plt.plot(dates.date2num(data[0]),data[1])
# plt.show()